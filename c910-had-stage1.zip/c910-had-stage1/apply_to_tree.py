#!/usr/bin/env python3
"""Install stage 1 into an OpenOCD tree, preserving changed files in a backup."""
from pathlib import Path
import argparse
import datetime
import re
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('openocd_root', type=Path)
parser.add_argument('--dry-run', action='store_true')
args = parser.parse_args()
root = args.openocd_root.resolve()
package = Path(__file__).resolve().parent
changes = {}

def edit(rel, transform):
    path = root / rel
    if not path.is_file():
        raise SystemExit('Missing file: ' + str(path))
    changes[rel] = transform(path.read_text()).encode()

def insert_once(text, marker, addition, present):
    if present in text:
        return text
    if text.count(marker) != 1:
        raise SystemExit('Unexpected source layout; cannot find unique marker: ' + marker)
    return text.replace(marker, marker + addition, 1)

def registry(s):
    return insert_once(s, 'static struct target_type *target_types[] = {',
                       '\n\t&c910_had_target,', '&c910_had_target,')
edit('src/target/target.c', registry)
edit('src/target/target_type.h', lambda s: insert_once(s,
    'extern struct target_type cortexa_target;',
    '\nextern struct target_type c910_had_target;',
    'extern struct target_type c910_had_target;'))

def commands(s):
    s = insert_once(s, '#include "config.h"\n#endif',
        '\n#include <target/newchip/newchip.h>', 'target/newchip/newchip.h')
    if not re.search(r'^\s*newchip_register_commands\s*,', s, re.M):
        pattern = r'(static int \(\* const command_registrants\[\]\)\(struct command_context \*cmd_ctx_value\) = \{)'
        s, count = re.subn(pattern, r'\1\n\tnewchip_register_commands,', s)
        if count != 1:
            raise SystemExit('Cannot find command_registrants[]')
    return s
edit('src/openocd.c', commands)

def makefile(s):
    if '%D%/newchip/libnewchip.la' not in s:
        s += '\n%C%_libtarget_la_LIBADD += %D%/newchip/libnewchip.la\n'
    if 'include %D%/newchip/Makefile.am' not in s:
        s += '\ninclude %D%/newchip/Makefile.am\n'
    return s
edit('src/target/Makefile.am', makefile)
for subdir in ('src/target/newchip', 'jtag_scripts'):
    for path in (package / subdir).iterdir():
        if path.is_file():
            changes[path.relative_to(package).as_posix()] = path.read_bytes()
changes = {rel: data for rel, data in changes.items()
           if not (root / rel).exists() or (root / rel).read_bytes() != data}
for rel in changes:
    print(('UPDATE ' if (root / rel).exists() else 'CREATE ') + rel)
if args.dry_run or not changes:
    print('Dry run; no files changed.' if args.dry_run else 'Already installed.')
    raise SystemExit(0)
backup = root / ('c910-backup-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir()
new_paths = []
# Back up everything before writing any source.
for rel in changes:
    dest = root / rel
    if dest.exists():
        saved = backup / rel
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dest, saved)
    else:
        new_paths.append(rel)
(backup / 'NEW_FILES.txt').write_text('\n'.join(new_paths) + '\n')
for rel, data in changes.items():
    dest = root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
print('Backup: ' + str(backup))
print('Installed. Regenerate build files; see README.md.')
